
public class ListaProfesor {

	private int Nprofesor,maximo;
	private Profesor[]lista;
	
	
	public ListaProfesor(int maximo) {
		// TODO Auto-generated constructor stub
		lista= new Profesor[maximo];
		Nprofesor = 0;
		this.maximo = maximo;
	}
	public boolean ingresarProfesor(Profesor profesor){
		if (Nprofesor < maximo){
			lista[Nprofesor]= profesor;
			Nprofesor ++;
			return true;
		}
		else{
			return false;
		}
	}
	public Profesor getProfesorI(int i){
		if (i >=0 && i < Nprofesor){
			return lista[i];
		}
		else{
			return null;
		}
	}
	public Profesor buscarProfesor(String correo){
		int i;
		for(i = 0; i < Nprofesor; i++){
			if (lista[i].getEmail().equals(correo)){
				break;
			}
		}
		if (i == Nprofesor){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public int getNprofesor() {
		return Nprofesor;
	}
	public void setNprofesor(int cantNprofesor) {
		this.Nprofesor = cantNprofesor;
	}
	public int getMaximo() {
		return maximo;
	}
	public void setMaximo(int maximo) {
		this.maximo = maximo;
	}
	public Profesor[] getLista() {
		return lista;
	}
	public void setLista(Profesor[] lista) {
		this.lista = lista;
	}
	
}
