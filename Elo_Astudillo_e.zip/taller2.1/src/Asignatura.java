
public abstract class Asignatura {
	private String Codigo;
	private String NombreAsignatura;
	private int Creditos;
	private String Tipo;
	
	public Asignatura(String codigo, String nombreAsignatura, int creditos, String tipo) {
		
		this.Codigo = codigo;
		this.NombreAsignatura = nombreAsignatura;
		this.Creditos = creditos;
		this.Tipo = tipo;
	}
	public String getNombreAsignatura() {
		return NombreAsignatura;
	}
	public void setNombreAsignatura(String nombreAsignatura) {
		NombreAsignatura = nombreAsignatura;
	}
	public int getCreditos() {
		return Creditos;
	}
	public void setTipo(String tipo) {
		Tipo = tipo;
	}
	public String getCodigo() {
		return Codigo;
	}
	public void setCodigo(String codigo) {
		Codigo = codigo;
	}
	public void setCreditos(int creditos) {
		Creditos = creditos;
	}
	public String getTipo() {
		return Tipo;
	}
}
