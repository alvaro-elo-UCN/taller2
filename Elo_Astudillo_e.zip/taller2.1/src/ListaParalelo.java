
public class ListaParalelo {
	private int Nparalelo,maximo;
	private setNroParalelo[]lista;
	public ListaParalelo(int maximo) {
		// TODO Auto-generated constructor stub
		lista= new setNroParalelo[maximo];
		Nparalelo = 0;
		this.maximo = maximo;
	}
	public boolean ingresarParalelo(setNroParalelo paralelo){
		if (Nparalelo < maximo){
			lista[Nparalelo]= paralelo;
			Nparalelo ++;
			return true;
		}
		else{
			return false;
		}
	}
	public setNroParalelo getParaleloI(int i){
		if (i >=0 && i < Nparalelo){
			return lista[i];
		}
		else{
			return null;
		}
	}
	public setNroParalelo buscarParalelo(int paralelo){
		int i;
		for(i = 0; i < Nparalelo; i++){
			if (lista[i].getNroParalelo()==(paralelo)){
				break;
			}
		}
		if (i == Nparalelo){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public setNroParalelo buscarParaleloprofe(String dato){
		int i;
		for(i = 0; i < Nparalelo; i++){
			if (lista[i].getProfesor().getEmail()==(dato)){
				break;
			}
		}
		if (i == Nparalelo){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public int getMaximo() {
		return maximo;
	}
	public void setMaximo(int max) {
		this.maximo = max;
	}
	public int getNparalelo() {
		return Nparalelo;
	}
	public void setNparalelo(int cantParalelo) {
		this.Nparalelo = cantParalelo;
	}
	public setNroParalelo[] getLista() {
		return lista;
	}
	public void setLista(setNroParalelo[] lista) {
		this.lista = lista;
	}
	
}
