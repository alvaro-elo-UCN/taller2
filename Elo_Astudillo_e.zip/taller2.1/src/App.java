import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import ucn.ArchivoEntrada;
import ucn.Registro;
import ucn.StdIn;

public class App {
	public static void read(SistemUCR sistema) throws IOException {
        
        BufferedReader txt = new BufferedReader(new FileReader("Estudiantes.txt"));
        String linea;
        
        while((linea = txt.readLine()) != null) {
            String[] partes = linea.split(",");
            
            String Run= partes[0];
            String Email=partes[1];
            int nivel= Integer.parseInt(partes[2]);
            String Pass=partes[3];;
            linea=txt.readLine();
            String[] partes2=linea.split(",");
            int cantAsignaturas=Integer.parseInt(partes2[0]);
            sistema.IngresarEstudiante(Run,Email,nivel,Pass);
        
            for(int i=0;cantAsignaturas>=i;i++) {
                linea=txt.readLine();
                String[] partes3 = linea.split(",");
                String Asignatura = partes3[0] ;
                double Nota= Double.parseDouble(partes3[1]);    
            }            
        }
        txt.close();
        
        ArchivoEntrada arch2=new ArchivoEntrada("Profesores.txt");
        while(!arch2.isEndFile()) {
            Registro reg = arch2.getRegistro();
            String rut = reg.getString();
            String correo = reg.getString();
            String contra = reg.getString();
            int salario = reg.getInt();
            sistema.IngresarProfesor(rut, correo, contra, salario);     
        }
        
        ArchivoEntrada arch3=new ArchivoEntrada("Paralos.txt");
        while(!arch3.isEndFile()) {
            Registro r=arch3.getRegistro();
            int Nparalelo= r.getInt();
            String codigo=r.getString();
            String nombreP=r.getString();  
            sistema.IngresarParalelo(Nparalelo, codigo, nombreP);
        }
            
        ArchivoEntrada arch4=new ArchivoEntrada("Asignaturas.txt");
        while(!arch4.isEndFile()) {            
            Registro r=arch4.getRegistro();
            String codigo= r.getString();
            String nombreAsignatura=r.getString();
            int creditos=r.getInt();
            String tipo =r.getString();
            
            if(tipo.equals("opcional")) {
                int MinimoCreditos= r.getInt();
                sistema.IngresarAsignaturaOpcional( codigo,nombreAsignatura, creditos, tipo, MinimoCreditos);
                
            }
            else {
                if(tipo.equals("obligario")) {
                    int NivelMalla=r.getInt();
                    int CantPrerequisito=r.getInt();
                    int CantCodigos=r.getInt();
                    for (int i=0;CantCodigos>=i;i++) {
                        String codigoAsignatura=r.getString();
                        Obligatoria.AgregarCodigos(codigoAsignatura);
                    } 
                    sistema.IngresarAsignaturaObligatoria(codigo, nombreAsignatura, creditos, tipo, NivelMalla, CantPrerequisito, CantCodigos);
                }       
            }
        }    
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SistemUCR sistema = new SistemUCRImpl();
		System.out.print("Ingrese Correo: ");
		String Email = StdIn.readString();
		System.out.print("Ingrese Contra: ");
		String pass = StdIn.readString();
		sistema.InicioSesion(Email, pass);
		
	}
}
