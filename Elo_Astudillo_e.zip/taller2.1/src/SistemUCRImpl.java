

import ucn.StdIn;

public class SistemUCRImpl implements SistemUCR {
	private ListaAlumno ListAlumno;
	private ListAsignatura  ListAsignatura;
	private ListaParalelo  ListParalelo;
	private ListaProfesor ListProfesor ;

	
	public SistemUCRImpl() {
		this.ListAlumno=new ListaAlumno(9999);
		this.ListAsignatura=new ListAsignatura(9999);
		this.ListParalelo=new ListaParalelo(9999);
		this.ListProfesor=new ListaProfesor(9999);
	}
	@Override
	public boolean IngresarEstudiante(String Rut, String Email, int Nivel, String Pass) {
		// TODO Auto-generated method stub
		Alumno alumno = new Alumno(Rut, Email, Nivel, Pass);
		boolean ingreso = ListAlumno.ingresarAlumno(alumno);
		return ingreso;
	}
	
	public boolean IngresarAsignaturaObligatoria(String Codigo, String NombreA, int Creditos, String tipo,
			int NivelMalla, int CantPrerequisito,int CantCodigos) {
		// TODO Auto-generated method stub
		Asignatura asignatura = new Obligatoria (Codigo, NombreA,Creditos,tipo,NivelMalla,CantPrerequisito, CantCodigos);
		boolean ingreso = ListAsignatura.ingresarAsignatura(asignatura);
		return ingreso;
		
	}
	@Override
	public boolean IngresarAsignaturaOpcional(String Codigo, String NombreA, int Creditos, String tipo,
			int MinimoCreditos) {
		// TODO Auto-generated method stub
		Asignatura asignatura = new Opcional (Codigo, NombreA,Creditos,tipo,MinimoCreditos);
		boolean ingreso = ListAsignatura.ingresarAsignatura(asignatura);
		return ingreso;
		
	}
	@Override
	public boolean IngresarProfesor(String Rut, String Correo, String Contrase�a, int Salario) {
		// TODO Auto-generated method stub
		Profesor profesor = new Profesor(Rut, Correo, Contrase�a, Salario);
		boolean ingreso = ListProfesor.ingresarProfesor(profesor);
		return ingreso;
		
	}
	public boolean IngresarParalelo(int Nparalelo, String Codigo,String rutProfesor) {
		// TODO Auto-generated method stub
		Profesor profesor = ListProfesor.buscarProfesor(rutProfesor);
		setNroParalelo paralelo = new setNroParalelo(Nparalelo,Codigo);
		paralelo.setProfesor(profesor);
		boolean ingreso = ListParalelo.ingresarParalelo(paralelo);
		return ingreso;
	}
	
	
	
	
	
	public void EliminacionAsignaturas(String dato) {
		// TODO Auto-generated method stub
		String Dato = "Asignaturas: ";
		for(int i =0; i < ListAlumno.getCantAlumno();i++){
			Alumno a = ListAlumno.getAlumnoI(i);
			if(a.getEmail().equals(dato)) {
				dato+=a.getCodigo();
			}
			System.out.print(dato);
			System.out.print("Ingrese Codigo Asignatura a eliminar: ");
			String resp = StdIn.readString();
			
		}
		
		
		
	}

	public void InscripcionAsignaturas(String dato) {
		String datos = "";
		String datosparalelo = "";
		for(int i =0; i< ListAlumno.getCantAlumno();i++) {
			Alumno a = ListAlumno.getAlumnoI(i);
			if(a.getEmail().equals(dato)) {
				int nivel = a.getNivel();
				for(int j = 0; j< ListAsignatura.getCantAsignatura();j++) {
					Asignatura asign = ListAsignatura.getAsignaturaI(j);
					if(asign instanceof Obligatoria) {
						Asignatura asign1 = (Obligatoria) asign;
						int nivelA = ((Obligatoria) asign).getNivelMalla();
						if(nivel<nivelA) {
							datos+=asign.getNombreAsignatura();
						}
					}
					datos+=asign.getNombreAsignatura()+"/Codigo: " +asign.getCodigo();
					
					
				}
				System.out.print(datos);
				
				
				
			}
		}
		System.out.print("Ingrese codigo de Asignatura a dar: ");
		String resp = StdIn.readString();
		Asignatura as = ListAsignatura.buscarAsignatura(resp);
		for(int k = 0; k<ListParalelo.getNparalelo();k++) {
			setNroParalelo pa = ListParalelo.getParaleloI(k);
			if(pa.getCodigo().equals(resp)) {
				datosparalelo+= "Paralelo: "+pa.getNroParalelo()+"Profesor: "+pa.getProfesor();
				
			}
			System.out.print("Ingrese Paralelo a dar: ");
			int numero = StdIn.readInt();
			if(pa.getNroParalelo()==numero) {
				Alumno al = ListAlumno.buscarAlumno(dato);
				al.setCodigo(resp);
			}
		}
		
		
	}
	
	public void ChequeoAlumnos(String profe) {
		// TODO Auto-generated method stub
		String datos="Paralelos\n";
		int paralelo;
		setNroParalelo profe1 = ListParalelo.buscarParaleloprofe(profe);
		for (int i = 0 ; i< ListParalelo.getNparalelo();i++) {
			if(profe1.getProfesor().getEmail().equals(profe)) {
				paralelo = profe1.getNroParalelo();
				datos+=profe1.getNroParalelo();
			}
		}
		System.out.print(datos);
		
	}
	
	public void IngresoNotaFinal(String dato) {
		String datos="";
		setNroParalelo profe1 = ListParalelo.buscarParaleloprofe(dato);
		for (int i = 0 ; i< ListParalelo.getNparalelo();i++) {
			if(profe1.getProfesor().getEmail().equals(dato)) {
				datos+=profe1.getCodigo();
				
						
				
			}
		}
	}

	public String ObtenerInformacionSemestre() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
}