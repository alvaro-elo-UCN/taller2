
public class Profesor {
	private String RunP;
	private String Email;
	private String PassP;
	private int Sueldo;
	private ListaParalelo lista;

	public ListaParalelo getLista() {
		return lista;
	}

	public Profesor(String rutP, String correo, String contra, int sueldo) {

		this.RunP = rutP;
		this.Email = correo;
		this.PassP = contra;
		this.Sueldo = sueldo;
		ListaParalelo lista = new ListaParalelo(4);
	}
	public String getRutP() {
		return RunP;
	}
	public void setRutP(String rutP) {
		RunP = rutP;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String correo) {
		Email = correo;
	}
	public String getPass() {
		return PassP;
	}
	public void setPass(String contra) {
		PassP = contra;
	}
	public int getSueldo() {
		return Sueldo;
	}
	public void setSueldo(int sueldo) {
		Sueldo = sueldo;
	}
	
}
