
public class ListaAlumno {
	private int Nalumno,maximo;
	private Alumno []lista;

	public ListaAlumno(int maximo) {
		// TODO Auto-generated constructor stub
		lista= new Alumno[maximo];
		Nalumno = 0;
		this.maximo = maximo;
	}
	public boolean ingresarAlumno(Alumno alumno){
		if (Nalumno < maximo){
			lista[Nalumno]= alumno;
			Nalumno ++;
			return true;
		}
		else{
			return false;
		}
	}
	public Alumno getAlumnoI(int i){
		if (i >=0 && i < Nalumno){
			return lista[i];
		}
		else{
			return null;
		}
	}
	public Alumno buscarAlumno(String correo){
		int i;
		for(i = 0; i < Nalumno; i++){
			if (lista[i].getEmail().equals(correo)){
				break;
			}
		}
		if (i == Nalumno){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public int getMaximo() {
		return maximo;
	}
	public void setMaximo(int max) {
		this.maximo = max;
	}
	
	public int getCantAlumno() {
		return Nalumno;
	}
	public void setCantAlumno(int cantAlumno) {
		this.Nalumno = cantAlumno;
	}
	public boolean eliminarAsignatura(Alumno alumno) {
		int i = 0;
		while(i < Nalumno && lista[i].getCodigo()!=alumno.getCodigo()) {
			i++;
		}
		if(i == Nalumno) {
		
			return false;
		}
		else {
			for(int k = i; k < Nalumno-1; k++) {
				lista[k]=lista[k+1];
			}
			Nalumno--;
			return true;
		}
	}
}
