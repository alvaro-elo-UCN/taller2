
public class Opcional extends Asignatura{
	public int MinimoCreditos;
	public static final String tipo="Opcional";
	
	public Opcional(String codigo, String nombreAsignatura, int creditos, String tipo,int MinimoCreditos) {
		super(codigo, nombreAsignatura, creditos, tipo);
		this.MinimoCreditos = MinimoCreditos;
		
	}
	public int getMinimoCreditos() {
		return MinimoCreditos;
	}
	
	public void setMinimoCreditos(int minimoCreditos) {
		MinimoCreditos = minimoCreditos;

	}
	
}
