
public interface SistemUCR {
	public void ChequeoAlumnos(String profe);
	public void IngresoNotaFinal(String dato);
	public void InicioSesion(String Email,String Pass);
	public void InscripcionAsignaturas(String dato);
	public void EliminacionAsignaturas(String dato);
	public boolean IngresarEstudiante(String Rut,String Email,int Nivel,String pass);
	public boolean IngresarAsignaturaObligatoria(String Codigo,String NombreA,int Creditos,String tipo,int NivelMalla,int CantPrerequisito,int CantCodigos);
	public boolean IngresarAsignaturaOpcional(String Codigo,String NombreA,int Creditos,String tipo,int MinimoCreditos);
	public boolean IngresarProfesor(String Rut,String Email,String Pass,int Sueldo);
	public boolean IngresarParalelo(int Nparalelo,String Codigo,String runProfesor);
	public String ObtenerInformacionSemestre();
}
