
public class setNroParalelo {
	private int NroParalelo ;
	private String Codigo;
	private Profesor profesor;
	private ListAsignatura lista;
	private Asignatura Nombre;
	public Profesor getProfesor() {
		return profesor;
	}
	public void setProfesor(Profesor profesor) {
		this.profesor = profesor;
	}
	public setNroParalelo(int NumeroParalelo,String Codigo) {
		this.Codigo=Codigo;
		this.NroParalelo=NumeroParalelo;
		profesor = null;
		Nombre=null;
		ListAsignatura lista = new ListAsignatura(999);
	}
	public ListAsignatura getLista() {
		return lista;
	}
	public void setLista(ListAsignatura lista) {
		this.lista = lista;
	}
	public Asignatura getNombre() {
		return Nombre;
	}
	public void setNombre(Asignatura nombre) {
		Nombre = nombre;
	}
	public int getNroParalelo() {
		return NroParalelo;
	}
	public void setNroParalelo(int numeroParalelo) {
		NroParalelo = numeroParalelo;
	}
	public String getCodigo() {
		return Codigo;
	}
	public void setCodigo(String codigo) {
		Codigo = codigo;
	}

}
