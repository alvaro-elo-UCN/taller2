
public class Obligatoria extends Asignatura {

	private int NivelMalla;
	private int Nprerequisito;
	private static String [] codigos;
	private int Ncodigos;;
	private static int N = 0;
	public Obligatoria(String codigo, String nombreAsignatura, int creditos, String tipo,int NivelMalla,int CantPrerequisito,int CantCodigos) {
		super(codigo, nombreAsignatura, creditos, tipo);
		this.NivelMalla= NivelMalla;
		this.Nprerequisito=CantPrerequisito;
		this.Ncodigos = CantCodigos;
	}
	
	public int getNprerequisito() {
		return Nprerequisito;
	}
	public void setNprerequisito(int cantPrerequisito) {
		Nprerequisito = cantPrerequisito;
	}
	public String[] getCodigos() {
		return codigos;
	}
	
	public int getNivelMalla() {
		return NivelMalla;
	}
	public void setNivelMalla(int nivelMalla) {
		NivelMalla = nivelMalla;
	}
	
	public void setCodigos(String[] codigos) {
		Obligatoria.codigos = codigos;
	}
	public int getNcodigos() {
		return Ncodigos;
	}
	public void setNcodigos(int cantCodigos) {
		Ncodigos = cantCodigos;
	}
	
	public static void AgregarCodigos(String codigoAsignatura) {
        
		codigos[N]=codigoAsignatura;
        N++;

    }
}
