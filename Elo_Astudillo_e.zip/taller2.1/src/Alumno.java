public class Alumno {
	private String Run;
	private String Email;
	private int Nivel;
	private String Pass;
	private int Ncreditos;
	private String Code;
	private ListAsignatura lista;
	
	public Alumno(String Rut,String Correo,int Nivel,String Contra) {
		this.Run=Rut;
		this.Email=Correo;
		this.Nivel=Nivel;
		this.Pass=Contra;
		Ncreditos=0;
		ListAsignatura lista = new ListAsignatura(100);
	
		
	}
	public ListAsignatura getLista() {
		return lista;
	}
	public void setLista(ListAsignatura lista) {
		this.lista = lista;
	}
	public String getCodigo() {
		return Code;
	}
	public void setCodigo(String codigo) {
		Code = codigo;
	}
	public int getCantcreditos() {
		return Ncreditos;
	}
	public void setCantcreditos(int cantcreditos) {
		this.Ncreditos = cantcreditos;
	}
	public String getRun() {
		return Run;
	}
	public void setRun(String rut) {
		Run = rut;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String correo) {
		Email = correo;
	}
	public int getNivel() {
		return Nivel;
	}
	public void setNivel(int nivel) {
		Nivel = nivel;
	}
	public String getContra() {
		return Pass;
	}
	public void setContra(String contra) {
		Pass = contra;
	}
	
	
	
}
