
public class ListAsignatura {
	private int Nasignatura,maximo;
	private Asignatura[]lista;
	
	public ListAsignatura(int maximo) {
		// TODO Auto-generated constructor stub
		lista= new Asignatura[maximo];
		Nasignatura = 0;
		this.maximo = maximo;
	}
	public boolean ingresarAsignatura(Asignatura alumno){
		if (Nasignatura < maximo){
			lista[Nasignatura]= alumno;
			Nasignatura ++;
			return true;
		}
		else{
			return false;
		}
	}
	public Asignatura getAsignaturaI(int i){
		if (i >=0 && i < Nasignatura){
			return lista[i];
		}
		else{
			return null;
		}
	}
	public Asignatura buscarAsignatura(String resp){
		int i;
		for(i = 0; i < Nasignatura; i++){
			if (lista[i].getCodigo().equals(resp)){
				break;
			}
		}
		if (i == Nasignatura){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public int getCantAsignatura() {
		return Nasignatura;
	}
	public void setCantAsignatura(int cantAsignatura) {
		this.Nasignatura = cantAsignatura;
	}
	public int getMax() {
		return maximo;
	}
	public void setMax(int max) {
		this.maximo = max;
	}
	public Asignatura[] getLista() {
		return lista;
	}
	public void setLista(Asignatura[] lista) {
		this.lista = lista;
	}
	
	
}
